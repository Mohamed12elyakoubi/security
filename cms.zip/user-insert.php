<?php

require 'user.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        
    try {
        $lastId = $user->add($_POST['email'], $_POST['password']);
        header("location:user-view.php?process=$lastId");
    } catch (\Exception $e) {
        echo "Fout bij het toevoegen" . $e->getMessage();
        die();
    }
} 
?>